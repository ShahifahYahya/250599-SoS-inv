package com.example.asus.sos_inv;

class AppCompatActivity {
}
